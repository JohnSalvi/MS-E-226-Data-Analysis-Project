MS&E 226 project code

How to run the analysis

1. Install the packages with pip install -r requirements.txt
2. Put Customer Churn.csv in this same folder.
3. Run python mse226_churn_analysis.py

The script uses all 2280 rows in that file as development data.
It does not split the file again.
Five-fold cross-validation still uses seed 226.
Results are written to the mse226_results folder.

How to reproduce the original split

The original complete dataset is not in this zip.
Run python reproduce_split.py and pass the path to your private original CSV.
That script removes exact duplicate rows.
It then makes an 80/20 split with seed 226.
