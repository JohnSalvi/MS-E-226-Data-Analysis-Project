import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


def main():
    if len(sys.argv) != 2:
        print("Usage: python reproduce_split.py path/to/original.csv")
        sys.exit(1)

    data = pd.read_csv(Path(sys.argv[1]))
    data.columns = [" ".join(name.split()) for name in data.columns]
    original_rows = len(data)
    data = data.drop_duplicates().reset_index(drop=True)
    duplicates_removed = original_rows - len(data)
    row_numbers = np.arange(len(data))
    development_rows, holdout_rows = train_test_split(
        row_numbers, test_size=0.20, random_state=226, stratify=data["Churn"]
    )
    print("Original rows:", original_rows)
    print("Duplicates removed:", duplicates_removed)
    print("Development rows:", len(development_rows))
    print("Holdout rows:", len(holdout_rows))


if __name__ == "__main__":
    main()
